// Section scroll js
$(document).ready(function () {
    /*
    * Plugin intialization
    */
    $('#pagepiling').pagepiling({
        menu: '#menu',
        anchors: ['page1', 'page2', 'page3', 'page4'],
        //sectionsColor: ['#030027', '#030027', '#030027', '#030027'],
        navigation: {
                       
        },
        scrollingSpeed: 1500,

        afterRender: function () {
            $('#vc_nav').addClass('v_active');
        },
        afterLoad: function (anchorLink, index) {
            if (index > 1) {
                $('#vc_nav').removeClass('v_active');
            } else {
                $('#vc_nav').addClass('v_active');
            }
        },
        normalScrollElementTouchThreshold: 10,
        touchSensitivity: 10,    
    });   
    $("#pp-nav").addClass("section_nav_vc");


});